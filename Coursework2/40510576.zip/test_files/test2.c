int main ( )
{
	int x = 3 ;
	long y = 5 ;
	long long z = x + y ;
	float g = x * y ;
	double f = x - y ;
	int a ;
	if ( z > 7 )
	{
		a = 1 ;
	}
	else
	{
		a = 2 ;
	}
	a ++ ;
	char* msg = "hello world!" ;
	int* int_pointer = & a ;
	short h = 3 ;
	return 0 ;
}