// Author: Giacomo Lorenzi
// Function to return vector of types

#pragma once

#include <string>
#include <vector>

std::vector<std::string> typesVector();