#pragma once

void promptInfos(char* inputFile);