#pragma once

void countLinesComments(char* inputFile);