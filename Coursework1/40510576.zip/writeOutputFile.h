#pragma once

void writeOutputFile(char* inputFile, char* outputFile);